﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using DanceStudioWebProject.Models;

namespace DanceStudioWebProject.ViewModels
{
    public class BookingsFeedback
    {
        [Key]
        public int BookingId { set; get; }
        public string choreographerName { set; get; }
        public string StudentName { set; get; }
        public string Feedback { set; get; }
    }
}