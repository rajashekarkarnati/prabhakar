﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DanceStudioWebProject.Models;

namespace DanceStudioWebProject.Controllers
{
    public class AdminController : Controller
    {
        private Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();

        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Adminlogin admin)
        {
            if (admin.AdminUserName != null)
            {
                var res = db.Adminlogins.Where(a => a.AdminUserName == admin.AdminUserName).SingleOrDefault();
                if (res != null)
                {
                    if (res.AdminPassword == admin.AdminPassword)
                    {
                        Session["isLogin"] = "true";
                        Session["username"] = res.AdminUserName;
                        Session["UserId"] = res.AdminUserName;
                        Session["Usertype"] = "admin";
                        return RedirectToAction("Index", "Admin");
                    }
                    else
                    {
                        ModelState.AddModelError("AdminPassword", "password not match");
                    }
                }
                else
                {
                    ModelState.AddModelError("AdminUsername", "username not exist");
                }
            }
            return View();
        }

        public ActionResult ManageUsers()
        {
            var users = db.Users.ToList();
            return View(users);
        }

        [HttpPost]
        public ActionResult ManageUsers(string username)
        {
            var users = db.Users.Where(a => a.username == username).ToList();
            return View(users);
        }

        public ActionResult EditUsers(string id)
        {
            var user = db.Users.Find(id);
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditUsers([Bind(Include = "username,Name,password,DanceType,Email,Gender,DOB,City,MobileNumber")] User user)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                return Content("<html><head><script>alert('Successfully Updated'); window.location.href = '/Admin/ManageUsers'</script></head></html>");
            }
            return View(user);
        }

        public ActionResult DeleteUsers(string id)
        {
            var user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return Content("<html><head><script>alert('Successfully Deleted'); window.location.href = '/Admin/ManageUsers'</script></head></html>");
        }
        public ActionResult ManageChoreographers()
        {
            var choreographers = db.choreographers.ToList();
            return View(choreographers);
        }

        [HttpPost]
        public ActionResult ManageChoreographers(string username)
        {
            var choreographers = db.choreographers.Where(a => a.username == username).ToList();
            return View(choreographers);
        }

        public ActionResult EditChoreographers(string id)
        {
            var user = db.choreographers.Find(id);
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditChoreographers([Bind(Include = "username,Name,password,DanceType,Email,Gender,DOB,City,MobileNumber")] choreographer choreographer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(choreographer).State = EntityState.Modified;
                db.SaveChanges();
                return Content("<html><head><script>alert('Successfully Updated'); window.location.href = '/Admin/ManageChoreographers'</script></head></html>");
            }
            return View(choreographer);
        }

        public ActionResult DeleteChoreographers(string id)
        {
            var choreographer = db.choreographers.Find(id);
            db.choreographers.Remove(choreographer);
            db.SaveChanges();
            return Content("<html><head><script>alert('Successfully Deleted'); window.location.href = '/Admin/ManageChoreographers'</script></head></html>");
        }


        public ActionResult Logout()
        {
            Session.RemoveAll();
            Session.Abandon();
            Session.Clear();
            return Content("<html><head><script> window.history.forward(1); window.location.href = '/Admin/Login'</script></head></html>");
        }
    }
}
