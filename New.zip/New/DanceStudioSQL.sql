create schema danceStudio

create table danceStudio.choreographer
(
	username varchar(10) primary key,
	Name varchar(25),
	[password] varchar(25) not null,
	DanceType varchar(10) not null,
	Email varchar(50) not null,
	Gender varchar(6) not null,
	DOB datetime not null,
	City varchar(25) not null,
	MobileNumber varchar(10) not null
)

select * from danceStudio.choreographer


create table danceStudio.Users
(
	username varchar(10) primary key,
	Name varchar(25),
	[password] varchar(25) not null,
	DanceType varchar(10) not null,
	Email varchar(50) not null,
	Gender varchar(6) not null,
	DOB datetime not null,
	City varchar(25) not null,
	MobileNumber varchar(10) not null
)


select * from danceStudio.Users



create table danceStudio.BookChoreographer
(
	BookingId int Identity(100,1) primary key,
	danceType varchar(10) not null,
	StudentName varchar(10) foreign key references danceStudio.Users(username),
	choreographername varchar(10) foreign key references danceStudio.choreographer(username),
	BookingDate datetime not null,
	Email varchar(50),
	BookingType varchar(10) check (BookingType in ('Home', 'Studio')),
	City varchar(25) not null,
	MobileNumber varchar(10) not null,
	StudentStrength int not null,
	BookingStatus varchar(10), 
	Rewardsgiven varchar(3),
	Attendancegiven varchar(3)
)


select * from danceStudio.BookChoreographer

select * from danceStudio.Attendance



update danceStudio.BookChoreographer set BookingStatus = 'Pending' where BookingId = 110
update danceStudio.BookChoreographer set Rewardsgiven = 'Yes' where BookingId = 100

create table danceStudio.Attendance
(
	
	AttendanceId int Identity primary key,

	BookingId int foreign key references danceStudio.BookChoreographer(BookingId),

	isPresent varchar(3)
)


create table danceStudio.Rewards
(
	id int identity primary key,
	BookingId int foreign key references danceStudio.BookChoreographer(BookingId),
	StudentName varchar(10) foreign key references danceStudio.Users(username),
	choreographername varchar(10) foreign key references danceStudio.choreographer(username),
	Rewards int 
)



create table danceStudio.Feedback
(
	id int identity primary key,
	BookingId int foreign key references danceStudio.BookChoreographer(BookingId),
	StudentName varchar(10) foreign key references danceStudio.Users(username),
	ChoreographerName varchar(10) foreign key references danceStudio.choreographer(username),
	Feedback varchar(1000)
)

create table danceStudio.Adminlogin
(
	Id int Identity primary key,
	AdminUserName varchar(10) not null,
	AdminPassword varchar(25) not null
)

insert into danceStudio.Adminlogin values('admin', 'admin')


create table danceStudio.ChoreographerLoginCredential
(
	Id int Identity primary key,
	username varchar(10) not null,
	[password] varchar(25) not null
)

create table danceStudio.UserLoginCredential
(
	Id int Identity primary key,
	username varchar(10) not null,
	[password] varchar(25) not null
)
